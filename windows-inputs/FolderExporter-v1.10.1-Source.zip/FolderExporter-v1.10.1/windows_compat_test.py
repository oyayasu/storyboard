"""Windows process checks and Storyboard Studio 0.12 recovery compatibility."""
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import json,os,subprocess,sys,unittest
import media_catalog as c

class CompatibilityTests(unittest.TestCase):
 def test_process_query_never_terminates_live_process(self):
  self.assertTrue(c.process_alive(os.getpid()))
  child=subprocess.Popen([sys.executable,'-c','import time;time.sleep(10)'])
  try:self.assertTrue(c.process_alive(child.pid));self.assertIsNone(child.poll())
  finally:child.terminate();child.wait()
  self.assertFalse(c.process_alive(child.pid))
 def journal(self,root,changed=False):
  link=root/'Studio Link';link.mkdir();stage=link/'.duplicate.tmp';stage.write_bytes(b'art');target=root/'archived.png';target.write_bytes(b'changed' if changed else b'art')
  current={'version':'new'};(link/'project.json').write_text(json.dumps(current))
  (link/'organization-journal.json').write_text(json.dumps({'phase':'committed','moves':[{'from':'old.png','to':'archived.png','stage':'Studio Link/.duplicate.tmp','deduplicate':True}],'documents':{'project.json':{'version':'old'}}}))
  return SimpleNamespace(root=root),stage,target,current
 def test_committed_shared_records_are_not_rolled_back(self):
  with TemporaryDirectory() as tmp:
   p,stage,target,current=self.journal(Path(tmp));c.recover_organization(p);self.assertFalse(stage.exists());self.assertEqual(target.read_bytes(),b'art');self.assertEqual(json.loads((p.root/'Studio Link/project.json').read_text()),current)
 def test_changed_duplicate_is_preserved(self):
  with TemporaryDirectory() as tmp:
   p,stage,target,_=self.journal(Path(tmp),True)
   with self.assertRaises(ValueError):c.recover_organization(p)
   self.assertEqual(stage.read_bytes(),b'art');self.assertEqual(target.read_bytes(),b'changed')
 def test_folder_rename_requires_storyboard_studio_recovery(self):
  with TemporaryDirectory() as tmp:
   root=Path(tmp);link=root/'Studio Link';link.mkdir();journal=link/'folder-rename-journal.json';journal.write_text('{}')
   with self.assertRaisesRegex(ValueError,'folder rename'):
    with c.workflow_lock(SimpleNamespace(root=root)):pass
   self.assertTrue(journal.exists());self.assertFalse((link/'.workflow.lock').exists())
 def test_archive_uses_shared_archive_parent(self):
  from studio_link_test import shared
  with TemporaryDirectory() as tmp:
   p=shared(tmp);p.manifest['archiveRoot']='Storyboard Archive';(p.root/'Studio Link/project.json').write_text(json.dumps(p.manifest));source=p.root/'rough.png';source.write_bytes(b'rough');card=p.reference['chapters'][0]['cards'][0];ch=p.reference['chapters'][0]
   p.manifest['storyboards']={'rough':{'relativePath':'rough.png','cardId':card['id'],'sourceCardId':card['id']}}
   (p.root/'Studio Link/project.json').write_text(json.dumps(p.manifest));(p.root/'Studio Link/storyboard-outputs.json').write_text(json.dumps({'files':{'rough.png':{'project':p.project_id}}}))
   c.archive_storyboards(p,{'source':{'sourceCardId':card['id'],'card':card,'chapter':ch}})
   new=json.loads((p.root/'Studio Link/project.json').read_text())['storyboards']['rough']['relativePath'];self.assertTrue(new.startswith('Storyboard Archive/'));self.assertEqual((p.root/new).read_bytes(),b'rough');self.assertFalse(source.exists())
if __name__=='__main__':unittest.main()
