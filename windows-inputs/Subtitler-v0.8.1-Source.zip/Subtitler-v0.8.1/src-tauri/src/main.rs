#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main(){whisper_desk_lib::run()}
