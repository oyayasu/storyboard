use std::{fs,path::PathBuf,process::Command};
use serde_json::json;
fn request_path()->PathBuf{if let Some(p)=std::env::var_os("SHARED_WHISPER_CONFIG"){return PathBuf::from(p).with_file_name("studio-request.json")}let home=std::env::var_os("HOME").map(PathBuf::from).unwrap_or_default();if cfg!(target_os="macos"){home.join("Library/Application Support/Shared Whisper/studio-request.json")}else if cfg!(windows){std::env::var_os("LOCALAPPDATA").map(PathBuf::from).unwrap_or(home.join("AppData/Local")).join("Shared Whisper/studio-request.json")}else{home.join(".config/shared-whisper/studio-request.json")}}
#[cfg(windows)]
fn launch_subtitler()->Result<(),String>{
 let mut candidates=Vec::new();
 for key in ["LOCALAPPDATA","ProgramFiles","ProgramFiles(x86)"]{if let Some(base)=std::env::var_os(key){let base=PathBuf::from(base);for folder in ["Subtitler","Programs/Subtitler"]{for file in ["whisper-desk.exe","Subtitler.exe"]{candidates.push(base.join(folder).join(file));}}}}
 if let Ok(current)=std::env::current_exe(){if let Some(parent)=current.parent().and_then(|p|p.parent()){candidates.push(parent.join("Subtitler/whisper-desk.exe"));}}
 if let Some(exe)=candidates.into_iter().find(|p|p.is_file()){return Command::new(exe).spawn().map(|_|()).map_err(|e|e.to_string())}
 // The document association retains custom installation locations. Read its
 // executable only; never execute registry command text as a shell command.
 let script=r#"$ErrorActionPreference='Stop'; $ext=Get-Item -LiteralPath 'Registry::HKEY_CLASSES_ROOT\.subtitler'; $id=$ext.GetValue(''); $key=Get-Item -LiteralPath ('Registry::HKEY_CLASSES_ROOT\'+$id+'\shell\open\command'); $cmd=$key.GetValue(''); if($cmd -match '^\s*"([^"]+\.exe)"'){ $matches[1] | ConvertTo-Json -Compress } elseif($cmd -match '^\s*(\S+\.exe)'){ $matches[1] | ConvertTo-Json -Compress }"#;
 if let Ok(output)=Command::new("powershell").args(["-NoProfile","-NonInteractive","-Command",script]).output(){if output.status.success(){if let Ok(path)=serde_json::from_slice::<String>(&output.stdout){let p=PathBuf::from(path);let name=p.file_name().and_then(|x|x.to_str()).unwrap_or("");if p.is_file()&&(name.eq_ignore_ascii_case("whisper-desk.exe")||name.eq_ignore_ascii_case("Subtitler.exe")){return Command::new(p).spawn().map(|_|()).map_err(|e|e.to_string())}}}}
 for name in ["whisper-desk.exe","Subtitler.exe"]{if Command::new(name).spawn().is_ok(){return Ok(())}}
 Err("Subtitler is not installed or its location is unavailable. Install Subtitler, then try Match timing again.".into())
}
#[tauri::command]
pub async fn open_subtitler(directory:String,project_id:String)->Result<(),String>{tauri::async_runtime::spawn_blocking(move||{
 let root=crate::studio_files::root(&directory)?;let manifest:serde_json::Value=serde_json::from_slice(&fs::read(crate::studio_files::local_file(&root,"Studio Link/project.json")?).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;if manifest["format"]!="studio-link-project-v1"||manifest["project"]["id"]!=project_id{return Err("Reconnect this project's folder before opening Subtitler".into())}
 let path=request_path();let parent=path.parent().ok_or("Shared tools folder unavailable")?;fs::create_dir_all(parent).map_err(|e|e.to_string())?;let request=json!({"format":"studio-subtitler-request-v1","requestId":format!("{}-{}",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos()),"directory":root.to_string_lossy(),"projectId":project_id,"action":"match-timing","activeRecording":manifest["activeRecording"]});crate::studio_files::atomic_json(parent,"studio-request.json",&request.to_string())?;
 #[cfg(target_os="macos")]let result=Command::new("open").args(["-b","local.filipe.whisperdesk"]).status();
 #[cfg(windows)]let result=launch_subtitler();
 #[cfg(not(any(target_os="macos",windows)))]let result=Command::new("Subtitler").spawn().map(|_|()).map_err(|e|e.to_string());
 #[cfg(target_os="macos")]if result.map_err(|e|e.to_string())?.success(){return Ok(())}else{return Err("Install the updated Subtitler app in Applications, then try again.".into())}
 #[cfg(not(target_os="macos"))]result.map_err(|e|e.to_string())
 }).await.map_err(|e|e.to_string())?}
