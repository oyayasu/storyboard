#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main() {
  storyboard_studio_lib::run();
}
